
$(document).ready(function() {
                        $("#queryresponse").dataTable({
                         searching: true,
                          responsive: true,
			  "fnDrawCallback": function(oSettings) {
                                        //if ( 5> oSettings.fnRecordsDisplay()) {
                                        //   $("#support_courses_paginate").show();
                                        //    $("#support_courses_length").show();
                                        //    $("#support_courses_filter").show();  
                                        //}
                                    }, 
                         "aaSorting": [],
                         "lengthMenu": [[5, 10, 25,50,100, -1], [5,10,25, 50,100, "All"]],
                        //"aoColumnDefs": [{ "bSortable": true, "aTargets": [ 0 ] }],
			"language": {
                          "paginate": {
                          "previous": "<<",
                          "next": ">>"
                        }
                        }
                        });
                        });
